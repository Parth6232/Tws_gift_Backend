/**
 * Bulk image upload: product-images folder se images ImageKit pe upload karke
 * products me jod deta hai (title se match karke).
 *
 * Kahan rakhna hai : <backend>/src/db/seedImages.js
 * Images kahan rakhni: <backend>/product-images/
 *
 *   Tareeka 1 (best): har product ka ek folder, folder ka naam = product ka title
 *     product-images/
 *       Jack & Jones Joren Round Neck - White/   <- isme 1 ya zyada images
 *           1.jpg  2.jpg  3.jpg                  <- pehli image main image banegi
 *       Pepe Jeans London Milano Polo - Black/
 *           front.png  back.png
 *
 *   Tareeka 2 (agar sirf 1-2 image hai): seedha file ka naam = product ka title
 *     product-images/Jack & Jones Joren Round Neck - White.jpg
 *     product-images/Jack & Jones Joren Round Neck - White_2.jpg
 *
 * Pehle check:  node src/db/seedImages.js --dry
 * Asli run:     node src/db/seedImages.js
 * Options:      --force    jin products me images pehle se hain unme bhi nayi add kar do
 *               --max=6    ek product ki max kitni images (default 6)
 *
 * - Sirf jpg/jpeg/png/webp lega (video wagairah ignore).
 * - Jis product me pehle se image hai use skip karta hai (--force ke bina).
 * - Folder ka naam title se match na ho to "Match nahi hua" list me dikhayega.
 */
require('dotenv').config(); // storage service se pehle env load hona zaroori hai
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '../../product-images');
const EXT = new Set(['.jpg', '.jpeg', '.png', '.webp']);
const MAX_BYTES = 20 * 1024 * 1024; // 20MB se badi file skip

const args = process.argv.slice(2);
const DRY = args.includes('--dry');
const FORCE = args.includes('--force');
const MAX = Number((args.find((a) => a.startsWith('--max=')) || '--max=6').split('=')[1]) || 6;

// "Jack & Jones - Black" aur "jack and jones black" dono same maane jayenge
const norm = (s) => s.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]/g, '');
const isImage = (f) => EXT.has(path.extname(f).toLowerCase());
const num = (f) => { const m = path.basename(f, path.extname(f)).match(/(\d+)\)?$/); return m ? Number(m[1]) : 0; };
// bina number wali file pehle (main image), phir 1,2,3... order me
const natural = (a, b) => num(a) - num(b) || a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });

function walk(dir) {
    const out = [];
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name);
        if (e.isDirectory()) out.push(...walk(p));
        else if (isImage(e.name) && fs.statSync(p).size <= MAX_BYTES) out.push(p);
    }
    return out.sort(natural);
}

// product-images ko { key(normalized title): { label, files[] } } me badalta hai
function collect() {
    if (!fs.existsSync(ROOT)) {
        console.error(`Folder nahi mila: ${ROOT}\nPehle ye folder banao aur images rakho.`);
        process.exit(1);
    }
    const groups = {};
    const add = (label, file) => {
        const k = norm(label);
        (groups[k] ||= { label, files: [] }).files.push(file);
    };
    for (const e of fs.readdirSync(ROOT, { withFileTypes: true })) {
        const p = path.join(ROOT, e.name);
        if (e.isDirectory()) {
            walk(p).forEach((f) => add(e.name, f));
        } else if (isImage(e.name) && fs.statSync(p).size <= MAX_BYTES) {
            const base = path.basename(e.name, path.extname(e.name)).replace(/[\s_\-]*\(?\d+\)?$/, '');
            add(base, p);
        }
    }
    Object.values(groups).forEach((g) => g.files.sort(natural));
    return groups;
}

(async () => {
    const groups = collect();
    const mongoose = require('mongoose');
    const productModel = require('../models/product.model');
    const { uploadfile } = require('../services/storage.services');

    await mongoose.connect(process.env.MONGO_URI);
    console.log('DB connected');

    const products = await productModel.find({}).select('title images');
    const byKey = new Map(products.map((p) => [norm(p.title), p]));

    const matched = [], unmatched = [];
    for (const [key, g] of Object.entries(groups)) {
        const p = byKey.get(key);
        if (p) matched.push({ p, g }); else unmatched.push(g);
    }
    const withoutImages = products.filter((p) => !p.images?.length && !matched.some((m) => m.p._id.equals(p._id)));

    console.log(`\nFolders/files mile: ${Object.keys(groups).length} | Match hue: ${matched.length} | Match nahi hue: ${unmatched.length}`);
    if (unmatched.length) {
        console.log('\nMatch nahi hua (naam title se alag hai):');
        unmatched.forEach((g) => console.log('  -', g.label));
    }
    if (withoutImages.length) {
        console.log(`\nIn ${withoutImages.length} products ki image abhi bhi nahi hai:`);
        withoutImages.forEach((p) => console.log('  -', p.title));
    }

    if (DRY) {
        console.log('\nDRY RUN: kuch upload nahi hua. Match hue products:');
        matched.forEach(({ p, g }) => console.log(`  ${p.title}  <-  ${Math.min(g.files.length, MAX)} image(s)${p.images?.length && !FORCE ? '  [skip: pehle se image hai]' : ''}`));
        return;
    }

    let done = 0, skipped = 0, failed = 0, uploaded = 0;
    for (const { p, g } of matched) {
        if (p.images?.length && !FORCE) { skipped++; continue; }
        try {
            const imgs = [];
            for (const file of g.files.slice(0, MAX)) {
                const safeName = path.basename(file).replace(/[^\w.\-]/g, '_');
                imgs.push(await uploadfile({ buffer: fs.readFileSync(file), originalname: safeName }));
                uploaded++;
            }
            await productModel.updateOne({ _id: p._id }, { $set: { images: FORCE ? [...(p.images || []), ...imgs] : imgs } });
            done++;
            console.log(`OK  ${p.title}  (${imgs.length} image)`);
        } catch (e) {
            failed++;
            console.error(`ERR ${p.title}: ${e.message}`);
        }
    }
    console.log(`\nDone. Products updated: ${done}, Images uploaded: ${uploaded}, Skipped: ${skipped}, Failed: ${failed}`);
})()
    .catch((e) => { console.error(e); process.exitCode = 1; })
    .finally(() => require('mongoose').disconnect());