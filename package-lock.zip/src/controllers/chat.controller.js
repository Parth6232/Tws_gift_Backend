const productModel = require('../models/product.model');

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// User ke message se related products dhundo (text search, fir keyword fallback)
const findProducts = async (query) => {
  const base = { isActive: true };
  let items = await productModel
    .find({ ...base, $text: { $search: query } }, { score: { $meta: 'textScore' } })
    .sort({ score: { $meta: 'textScore' } })
    .limit(5)
    .populate('category', 'name');

  if (!items.length) {
    const words = query.split(/\s+/).filter((w) => w.length > 2).slice(0, 5).map(escapeRegex);
    if (words.length) {
      items = await productModel
        .find({
          ...base,
          $or: words.flatMap((w) => [{ title: new RegExp(w, 'i') }, { tags: new RegExp(w, 'i') }]),
        })
        .limit(5)
        .populate('category', 'name');
    }
  }
  return items;
};

const productLine = (p) =>
  `- ${p.title} | Rs.${p.price}${p.comparePrice ? ` (MRP Rs.${p.comparePrice})` : ''} | ${
    p.category?.name || 'General'
  } | ${p.soldOut ? 'Sold out' : 'In stock'} | link: /product/${p.slug}`;

const buildSystemPrompt = (matched, fallback) => `You are "Dear", the friendly shopping assistant of DearKeeps, an online store for personalized gifts. Tagline: "Little Gifts. Forever Memories."

Rules:
- Reply in the same language the user writes in (English, Hindi or Hinglish). Keep replies short (2-4 sentences), warm and helpful.
- Use ONLY the product data below for product names, prices and availability. Never invent products, prices, offers or delivery promises.
- If nothing below fits, say so honestly and suggest browsing the Shop page or describing the occasion/budget.
- Prices are in Indian Rupees (Rs.). Personalization (name engraving, photo print) is available on many products; for exact details ask the user to open the product page.
- For orders, delivery time, refunds or anything not in the data, tell the user to use the contact options on the website. Do not make up policies.
- Politely decline questions unrelated to gifts or the store.

${matched.length ? `Products matching the user's latest message:\n${matched.map(productLine).join('\n')}` : 'No product matched the latest message.'}
${!matched.length && fallback.length ? `\nPopular products you may suggest:\n${fallback.map(productLine).join('\n')}` : ''}`;

// POST /api/chat   body: { messages: [{ role: 'user'|'assistant', content: '...' }] }
const chat = async (req, res) => {
  const raw = Array.isArray(req.body?.messages) ? req.body.messages : [];
  const messages = raw
    .filter((m) => ['user', 'assistant'].includes(m?.role) && typeof m?.content === 'string' && m.content.trim())
    .slice(-10)
    .map((m) => ({ role: m.role, content: m.content.trim().slice(0, 500) }));

  const last = messages[messages.length - 1];
  if (!last || last.role !== 'user') {
    return res.status(400).json({ message: 'Last message user ka hona chahiye' });
  }
  if (!process.env.GROQ_API_KEY) {
    return res.status(503).json({ message: 'Chatbot abhi configure nahi hai' });
  }

  const matched = await findProducts(last.content);
  const fallback = matched.length
    ? []
    : await productModel.find({ isActive: true, isBestSeller: true }).limit(5).populate('category', 'name');

  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env.GROQ_API_KEY}`,
    },
    body: JSON.stringify({
      model: process.env.GROQ_MODEL || 'llama-3.3-70b-versatile',
      messages: [{ role: 'system', content: buildSystemPrompt(matched, fallback) }, ...messages],
      temperature: 0.5,
      max_tokens: 400,
    }),
  });

  if (!response.ok) {
    console.error('Chat provider error:', response.status, await response.text());
    return res.status(502).json({ message: 'Chatbot abhi available nahi hai, thodi der baad try karo' });
  }

  const data = await response.json();
  const reply = data.choices?.[0]?.message?.content?.trim();
  if (!reply) return res.status(502).json({ message: 'Chatbot se jawab nahi mila' });

  res.json({
    reply,
    // Frontend chat me product cards dikhane ke liye (sirf jab search match hua)
    products: matched.map((p) => ({
      _id: p._id,
      title: p.title,
      slug: p.slug,
      price: p.price,
      comparePrice: p.comparePrice,
      image: p.images?.[0]?.url || null,
      soldOut: p.soldOut,
    })),
  });
};

module.exports = { chat };