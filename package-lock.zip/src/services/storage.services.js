const { ImageKit, toFile } = require('@imagekit/nodejs');

const ImageKitClient = new ImageKit({
  privateKey: process.env.IMAGEKIT_PRIVATE_KEY,
});

// file = multer file (buffer + originalname). Returns { url, publicId }
// publicId me ImageKit ka fileId store hota hai
async function uploadfile(file, folder = '/TWS Gift/products') {
  const result = await ImageKitClient.files.upload({
    file: await toFile(file.buffer, file.originalname),
    fileName: 'tws_' + Date.now() + '_' + file.originalname,
    folder,
  });
  return { url: result.url, publicId: result.fileId };
}

async function deletefile(fileId) {
  await ImageKitClient.files.delete(fileId);
}

module.exports = { uploadfile, deletefile };